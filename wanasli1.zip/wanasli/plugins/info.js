let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 INFO BOT 〙 ═
┏━━━━━━━━━━━━━━
┣⊱ *Admin*      : WANBYONE M19
┣⊱ *No Admin*  : wa.me/6285794065296 / wa.me/6285703153719
┣⊱ *Instagram*  : https://www.instagram.com/wanbyone_m19/
┣⊱ *Youtube*    : https://youtube.com/channel/UC6ZhjqSGko_wlOu28wrBnRw
┗━━━━━━━━━━━━━━
`.trim(), m)
}
handler.help = ['info']
handler.tags = ['info']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

